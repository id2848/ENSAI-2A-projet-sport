# Point Hebdomadaire - Projet

Date : Jeudi ...
Semaine n° ...

## Tâches réalisées cette semaine

> Exemples : `- [x] Tâche 1` ou - `ras`

### Nom Prénom élève 1

### Nom Prénom élève 2

### Nom Prénom élève 3

### Nom Prénom élève 4

### Nom Prénom élève 5

---

## Backlog

> Liste des tâches en attente de prise en charge.

### Prioritaires

### Secondaires