INSERT INTO joueur(pseudo, mdp, age, mail, fan_pokemon) VALUES
('admin',      '0000',     0,       'admin@projet.fr',      null),
('a',             'a',     20,      'a@ensai.fr',           true),
('maurice',    '1234',     20,      'maurice@ensai.fr',     true),
('batricia',   '9876',     25,      'bat@projet.fr',        false),
('miguel',     'abcd',     23,      'miguel@projet.fr',     true),
('gilbert',    'toto',     21,      'gilbert@projet.fr',    false),
('junior',     'aaaa',     15,      'junior@projet.fr',     true);
