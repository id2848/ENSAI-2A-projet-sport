# Pour definir le repertoire courant comme un package
