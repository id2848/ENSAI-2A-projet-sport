a, b = 0, 5

for i in range(b):
    print(" " * a, end="")
    a += 1
    print("Hello <firstname>")

#   TEST